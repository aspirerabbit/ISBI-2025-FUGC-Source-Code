from .visualizecommand import VisualizeCommand

available_commands = [
    VisualizeCommand,
]
