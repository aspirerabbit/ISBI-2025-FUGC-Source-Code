import os
import torch
import torch.nn as nn
from config.config import Config
from models.unet import U_Net
import torch.nn.functional as F
from utils.augmentation import BasicTsf
from utils.dataset import UnlabeledDataSets, LabeledDataSets
from torch.utils.data import DataLoader
from utils.criterion import MyCriterion

import torch


class CBR(nn.Module):
    def __init__(self, in_c):
        super().__init__()
        self.conv1 = nn.Conv2d(in_c, 3, kernel_size=3, stride=1, padding=1, bias=True)
        self.bn = nn.BatchNorm2d(3)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.act(self.bn(self.conv1(x)))


class ProjectHead(nn.Module):
    def __init__(self, in_c, scale):
        super().__init__()
        self.cbr = CBR(in_c)
        self.conv = nn.Conv2d(3, 3, kernel_size=1, stride=1, padding=0)
        self.scale = scale

    def forward(self, x):
        x = self.cbr(x)
        x = F.interpolate(
            x, scale_factor=self.scale, mode="bilinear", align_corners=True
        )
        return self.conv(x)


class Aux(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = U_Net(n1=8, is_aux=True)
        self.p1 = ProjectHead(16, 2)
        self.p2 = ProjectHead(32, 4)
        self.p3 = ProjectHead(64, 8)

    def forward(self, x):
        x, x1, x2, x3 = self.model(x)
        return x, self.p1(x1), self.p2(x2), self.p3(x3)


class EMA:
    def __init__(self, model, decay):
        self.model = model
        self.decay = decay
        self.shadow = {}
        self.backup = {}

    def register(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.data.clone()

    def update(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.shadow
                new_average = (
                    1.0 - self.decay
                ) * param.data + self.decay * self.shadow[name]
                self.shadow[name] = new_average.clone()

    def apply_shadow(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.shadow
                self.backup[name] = param.data
                param.data = self.shadow[name]

    def restore(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.backup
                param.data = self.backup[name]
        self.backup = {}


def retrain():
    # Load configuration
    config = Config()
    labeled_dir = config.get("paths", "labeled_dir")
    unlabeled_dir = config.get("paths", "unlabeled_dir")

    output_dir = config.get("paths", "output_dir")

    lr = config.get("training", "learning_rate")
    gpu_id = config.get("training", "gpu_id")
    batch_labeled = config.get("training", "batch_labeled")
    batch_unlabeled = config.get("training", "batch_unlabeled")
    epochs = config.get("training", "epochs")
    warmup_epochs = config.get("training", "warmup_epoch")

    # get dataloader
    ls_t = os.listdir(os.path.join(labeled_dir, "images"))
    ls_u = os.listdir(os.path.join(unlabeled_dir, "images"))
    tsf = BasicTsf()
    dataset_l = LabeledDataSets(labeled_dir, ls_t, tsf)
    dataset_u = LabeledDataSets(unlabeled_dir, ls_u, tsf)

    labeled_loader = DataLoader(
        dataset_l, batch_size=batch_labeled, shuffle=True, num_workers=4
    )
    unlabeled_loader = DataLoader(
        dataset_u, batch_size=batch_unlabeled, shuffle=True, num_workers=4
    )

    # Setup directories
    os.makedirs(output_dir, exist_ok=True)

    # Initialize logger
    # logger = MetricsLogger(save_dir=output_dir)

    # Initialize model
    device = torch.device(f"cuda:{gpu_id}" if torch.cuda.is_available() else "cpu")
    # model1 = U_Net(n1=8, is_drop=False).to(device)
    model1 = Aux().to(device)
    # state_dict = torch.load('/home/chenyu/retrain/model_mlp.pth')
    # for k in list(state_dict.keys()):
    #     if "head" in k:
    #         del state_dict[k]
    # model1.load_state_dict(state_dict, strict=False)

    ema = EMA(model1, decay=0.999)
    ema.register()

    optimizer1 = torch.optim.AdamW(
        filter(lambda p: p.requires_grad, model1.parameters()),
        lr=lr,
        betas=(0.9, 0.999),
        weight_decay=0.1,
    )
    cosine_epochs = epochs - warmup_epochs
    # 创建Cosine Annealing调度器
    from torch.optim.lr_scheduler import CosineAnnealingLR

    scheduler1 = CosineAnnealingLR(optimizer1, T_max=cosine_epochs)

    criterion = MyCriterion(epochs + 1)  # combined loss function

    labeled_iter = iter(labeled_loader)
    unlabeled_iter = iter(unlabeled_loader)
    iter_num = 0
    max_iterations = epochs * len(unlabeled_loader)
    print(max_iterations)
    for epoch in range(1, epochs + 1):
        model1.train()

        # Warmup阶段的学习率调整
        if epoch <= warmup_epochs:
            warmup_factor = epoch / warmup_epochs
            for param_group in optimizer1.param_groups:
                param_group["lr"] = lr * warmup_factor

        for batch_idx, _ in enumerate(
            range(len(unlabeled_loader))
        ):  # 以无标签数据为主循环
            try:
                image_l, label_l = next(labeled_iter)
            except StopIteration:
                labeled_iter = iter(labeled_loader)
                image_l, label_l = next(labeled_iter)

            try:
                image_u, label_u = next(unlabeled_iter)
            except StopIteration:
                unlabeled_iter = iter(unlabeled_loader)
                image_u, label_u = next(unlabeled_iter)

            print(f"Epoch[{epoch}/{epochs}] | Batch {batch_idx}: ", end="")

            image_l = image_l.to(
                dtype=torch.float32, device=device
            )  # (BS, 3, 336, 544)
            label_l = label_l.to(
                device=device
            )  # (BS,336,544)  int64  0: background 1:ps 2:fh
            image_u = image_u.to(dtype=torch.float32, device=device)  #
            label_u = label_u.to(
                device=device
            )  # (BS,336,544)  int64  0: background 1:ps 2:fh
            # sup loss:
            outputs_l, outputs_l1, outputs_l2, outputs_l3 = model1(image_l)
            loss1 = 0.5 * criterion(outputs_l, label_l, epoch)
            loss11 = 0.3 * criterion(outputs_l1, label_l, epoch)
            loss12 = 0.15 * criterion(outputs_l2, label_l, epoch)
            loss13 = 0.05 * criterion(outputs_l3, label_l, epoch)
            loss1 = loss1 + loss11 + loss12 + loss13

            # semi loss:
            outputs_u, outputs_u1, outputs_u2, outputs_u3 = model1(image_u)
            loss2 = 0.5 * criterion(outputs_u, label_u, epoch)
            loss21 = 0.3 * criterion(outputs_u1, label_u, epoch)
            loss22 = 0.15 * criterion(outputs_u2, label_u, epoch)
            loss23 = 0.05 * criterion(outputs_u3, label_u, epoch)
            loss2 = loss2 + loss21 + loss22 + loss23

            loss = 0.6 * loss1 + 0.2 * loss2

            print(f" loss1: {loss1.item():.4f} || loss2: {loss2.item():.4f}")
            # print(f'ce:{ce.item():.4f} | dice:{dice.item():.4f} | loss1: {model1_loss.item():.4f}')

            optimizer1.zero_grad()
            loss.backward()
            # model1_loss.backward()
            # model2_loss.backward()
            optimizer1.step()
            # Update EMA
            ema.update()
            iter_num = iter_num + 1

            if epoch > warmup_epochs:
                scheduler1.step()
        if epoch % 150 == 0:
            # Apply EMA weights before saving the model
            ema.apply_shadow()
            torch.save(
                model1.model.state_dict(),
                os.path.join(output_dir, f"unet8_{epoch}.pth"),
            )
            ema.restore()


if __name__ == "__main__":
    retrain()
