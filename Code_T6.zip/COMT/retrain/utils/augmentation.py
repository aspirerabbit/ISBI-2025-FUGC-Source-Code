import numpy as np
import torch
from torchvision import transforms as T
from torchvision.transforms import functional as F
import random
from torchvision import transforms
from PIL import Image

def to_long_tensor(pic):
    # handle numpy array
    img = torch.from_numpy(np.array(pic, np.uint8))
    # backward compatibility
    return img.long()

class RandomResizedCropWithMask:
    def __init__(self, size):
        self.size = size
        self.transform = transforms.RandomResizedCrop(size)

    def __call__(self, image, mask=None):
        if mask is not None:
            # Apply the random resized crop to both image and mask
            i, j, h, w = transforms.RandomResizedCrop.get_params(image, scale=(0.5, 1.0), ratio=( 3./4., 4./ 3.))
            image_cropped = transforms.functional.crop(image, i, j, h, w)
            mask_cropped = transforms.functional.crop(mask, i, j, h, w)

            # Resize the cropped images to the target size
            image_resized = image_cropped.resize((self.size[1], self.size[0]), Image.Resampling.LANCZOS)
            mask_resized = mask_cropped.resize((self.size[1], self.size[0]), Image.Resampling.NEAREST)  # Use nearest for mask

            return image_resized, mask_resized
        else:
            # Apply the random resized crop to both image and mask
            i, j, h, w = transforms.RandomResizedCrop.get_params(image, scale=(0.5, 1.0), ratio=( 3./4., 4./ 3.))
            image_cropped = transforms.functional.crop(image, i, j, h, w)

            # Resize the cropped images to the target size
            image_resized = image_cropped.resize((self.size[1], self.size[0]), Image.Resampling.LANCZOS)

            return image_resized         

class BasicTsf:
    """
    基础数据增强策略
    """
    def __init__(self, img_size = (336,544), long_mask=True):
        self.cutout = (32, 32)
        self.p_flip = 0.5
        self.p_rota = 0.5
        self.p_gama = 0.2
        self.p_resizecrop = 0.3
        self.img_size = img_size
        color_jitter_params = (0.1, 0.1, 0.1, 0.1)
        self.color_tf = T.ColorJitter(*color_jitter_params)
        self.long_mask = long_mask
        self.resizecrop = RandomResizedCropWithMask(img_size)

    def __call__(self, image, mask=None):
        if mask is None:
            image = image.transpose(1,2,0).astype(np.uint8)
            if np.random.rand() < self.p_gama:
                c = 1
                g = np.random.randint(10, 25) / 10.0
                # g = 2
                image = (np.power(image / 255, 1.0 / g) / c) * 255
                image = image.astype(np.uint8)
            # transforming to PIL image
            image = F.to_pil_image(image)
            if np.random.rand() < self.p_resizecrop:
                image = self.resizecrop(image)
            # random cutout
            if self.cutout:
                # 将图像转换为numpy数组
                image_np = np.array(image)
                num = random.randint(0, 5)
                for i in range(num):
                    # 随机选择裁剪区域
                    i, j, h, w = T.RandomCrop.get_params(image, self.cutout)
                    # 将裁剪区域置0
                    image_np[i:i+h, j:j+w, :] = 0
                # 将numpy数组转回PIL图像
                image = F.to_pil_image(image_np)
            # random horizontal flip
            if np.random.rand() < self.p_flip:
                image = F.hflip(image)
            # random rotation
            if np.random.rand() < self.p_rota:
                angle = T.RandomRotation.get_params((-30, 30))
                image = F.rotate(image, angle)
            image_tea = image
            image = self.color_tf(image)
            image_tea = F.to_tensor(image_tea)
            image_tea = image_tea.numpy()
            image_tea = torch.as_tensor(image_tea, dtype=torch.float32)
            image = F.to_tensor(image)
            image = image.numpy()
            image = torch.as_tensor(image, dtype=torch.float32)
            return image, image_tea
        else:
            image = image.transpose(1,2,0).astype(np.uint8)
            mask = mask.transpose(1,2,0).astype(np.uint8)
            if np.random.rand() < self.p_gama:
                c = 1
                g = np.random.randint(10, 25) / 10.0
                # g = 2
                image = (np.power(image / 255, 1.0 / g) / c) * 255
                image = image.astype(np.uint8)
            # transforming to PIL image

            image, mask = F.to_pil_image(image), F.to_pil_image(mask)
            if np.random.rand() < self.p_resizecrop:
                image, mask = self.resizecrop(image, mask)
            # random cutout
            if self.cutout:
                
                # 将图像转换为numpy数组
                image_np = np.array(image)
                mask_np = np.array(mask)
                
                num = random.randint(0, 5)
                for i in range(num):
                    # 随机选择裁剪区域
                    i, j, h, w = T.RandomCrop.get_params(image, self.cutout)
                    # 将裁剪区域置0
                    image_np[i:i+h, j:j+w, :] = 0
                    mask_np[i:i+h, j:j+w] = 0
                
                # 将numpy数组转回PIL图像
                image = F.to_pil_image(image_np)
                mask = F.to_pil_image(mask_np)
            # random horizontal flip
            if np.random.rand() < self.p_flip:
                image, mask = F.hflip(image), F.hflip(mask)
            # random rotation
            if np.random.rand() < self.p_rota:
                angle = T.RandomRotation.get_params((-30, 30))
                image, mask = F.rotate(image, angle), F.rotate(mask, angle)
            # student strong augmentation
            image = self.color_tf(image)
            image = F.to_tensor(image)
            image = image.numpy()
            image = torch.as_tensor(image, dtype=torch.float32)

            if not self.long_mask:
                mask = F.to_tensor(mask)
            else:
                mask = to_long_tensor(mask)
            return image, mask
        